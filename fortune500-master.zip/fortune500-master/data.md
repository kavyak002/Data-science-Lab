The original data was obtained by downloading the [Fortune 500 website](http://fortune.com/fortune500/) to a local file which was  then scraped. Lat and Lon measurements were obtained from the city location so will not be precisely located.  
A [csv file](https://github.com/pssguy/fortune500/blob/master/fortune500.csv) was produced which is displayed in table format below    
Map data obtained from [Natural Earth](http://www.naturalearthdata.com/downloads/50m-cultural-vectors/50m-admin-1-states-provinces/)
