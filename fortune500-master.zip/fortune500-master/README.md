# fortune500
Analyses of top US companies using [shinydashboard](https://github.com/rstudio/shinydashboard)

Initially map data based on [RStudio leaflet package](https://github.com/rstudio/leaflet) and  
   [rcstatebin](https://github.com/ramnathv/rcstatebin) packages
